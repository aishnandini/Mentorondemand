package com.cognizant.controller;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cognizant.entity.Mentor;
import com.cognizant.entity.PaymentDetails;
import com.cognizant.entity.Technologies;
import com.cognizant.entity.User;
import com.cognizant.service.AdminService;
import com.cognizant.service.MentorService;
import com.cognizant.service.UserService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/admin")

public class AdminController 
{
	@Autowired
	private UserService userService;

	@Autowired
    private AdminService adminService;
	
	@Autowired
	private MentorService mentorService;
	
	@RequestMapping(value = "/authorization", method = RequestMethod.POST)
	public String login(@RequestBody User login) throws ServletException 
	{
		String jwtToken = "";
		if (login.getUsername() == null || login.getPassword() == null)
		{
			throw new ServletException("Please fill in username and password");
		}
		String username = login.getUsername();
		String password = login.getPassword();
		User user = userService.findUser(username, password);
		String usertype=user.getUsertype();
		String pwd = user.getPassword();
		if (!password.equals(pwd)) 
		{
			throw new ServletException("Invalid login. Please check your username and password.");
		}
		if(usertype.equalsIgnoreCase("admin"))
		{
		jwtToken = Jwts.builder().setSubject(username).claim("roles", "user")
				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();
		}
		else
		{
			throw new ServletException("No an Admin");
		}
		return jwtToken;
	}
	
	/*******************ADD,UPDATE,REMOVE TECHNOLOGY********************/
	@RequestMapping(value = "/add/technology", method = RequestMethod.POST)
	public Technologies addTechnology(@RequestBody Technologies technologies) 
	{
		return adminService.save(technologies);
	}
	
	@RequestMapping(value = "/update/technology", method = RequestMethod.POST)
	public Technologies updateTechnology(@RequestBody Technologies technologies) 
	{
		return adminService.save(technologies);
	}
	
	@Transactional
	@RequestMapping(value = "/delete/technology", method = RequestMethod.POST)
	public String deleteTechnology(@RequestParam long technologyId)
	{
	 adminService.deleteByTechnologyId(technologyId);
	 return "Technology Deleted";
	}
	
	/*******************BLOCK AND UNBLOCK USER********************/
	 @RequestMapping(value = "/block/user", method = RequestMethod.POST)
	 @Transactional
	 public String blockUser(@RequestParam long id) {
	 User user=new User();
	 user=userService.findById(id);
	 if(user.getIsblock()==true)
	 {
		 return "User is already blocked";
	 }
	 else
	 {
		 user.setIsblock(true);
		 return "User is now blocked";
	 }
	 }

	 @RequestMapping(value = "/unblock/user", method = RequestMethod.POST)
	 @Transactional
	 public String unblockUser(@RequestParam long id) {
	 User user=new User();
	 user=userService.findById(id);
	 if(user.getIsblock()==true)
	 {
		 user.setIsblock(false);
		 return "User is now unblocked";
	 }
	 else
	 {
		 return "User is already unblocked";
	 }
	 }
	 
	 /*******************BLOCK AND UNBLOCK MENTOR********************/
	 @RequestMapping(value = "/block/mentor", method = RequestMethod.POST)
	 @Transactional
	 public String blockMentor(@RequestParam long mentorId) {
	 Mentor mentor=new Mentor();
	 mentor=mentorService.findByMentorId(mentorId);
	 if(mentor.getIsblock()==true)
	 {
		 return "Mentor is already blocked";
	 }
	 else
	 {
		 mentor.setIsblock(true);
		 return "Mentor is now blocked";
	 }
	 }

	 @RequestMapping(value = "/unblock/mentor", method = RequestMethod.POST)
	 @Transactional
	 public String unblockMentor(@RequestParam long mentorId) {
	 Mentor mentor=new Mentor();
	 mentor=mentorService.findByMentorId(mentorId);
	 if(mentor.getIsblock()==true)
	 {
		 mentor.setIsblock(false);
		 return "Mentor is now unblocked";
	 }
	 else
	 {
		 return "Mentor is already unblocked";
	 }
	 }
	 
	 /*******************SEARCH THE PAYMENTS MADE AND DISPLAY REPORTS********************/
	 @RequestMapping(value = "/findall", method = RequestMethod.POST)
	  java.util.List<PaymentDetails> searchall()
	 {
	  Iterable<PaymentDetails> itr=adminService.findAll();
	  Iterator<PaymentDetails> itr1=itr.iterator();
	  java.util.List<PaymentDetails> list=new ArrayList<>();
	  while(itr1.hasNext())
	  {
	  list.add(itr1.next());
	  }
	  return list;
	 }

}

