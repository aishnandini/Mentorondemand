package com.cognizant.dao;


import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.entity.Technologies;

@Repository
public interface AdminDao extends CrudRepository<Technologies, Serializable>
{
	
	void deleteByTechnologyId(long technologyId);
	

}

