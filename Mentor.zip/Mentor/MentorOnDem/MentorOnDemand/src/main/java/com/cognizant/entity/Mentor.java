package com.cognizant.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Mentor")
public class Mentor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long mentorId;
	private String firstName;
	private String lastName;
	private String username;
	private String password;
	private String email;
	private Date date;
	private long contactNumber;
	private String linkedinUrl;
	private float yearOfExperiance;
	private Boolean confirmSignUp;
	private boolean resetPassword;
	private boolean isblock;
	public long getMentorId() {
		return mentorId;
	}
	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getLinkedinUrl() {
		return linkedinUrl;
	}
	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}
	public float getYearOfExperiance() {
		return yearOfExperiance;
	}
	public void setYearOfExperiance(float yearOfExperiance) {
		this.yearOfExperiance = yearOfExperiance;
	}
	public Boolean getConfirmSignUp() {
		return confirmSignUp;
	}
	public void setConfirmSignUp(Boolean confirmSignUp) {
		this.confirmSignUp = confirmSignUp;
	}
	public boolean isResetPassword() {
		return resetPassword;
	}
	public void setResetPassword(boolean resetPassword) {
		this.resetPassword = resetPassword;
	}
	public boolean getIsblock() {
		return isblock;
	}
	public void setIsblock(boolean isblock) {
		this.isblock = isblock;
	}
	@Override
	public String toString() {
		return "Mentor [mentorId=" + mentorId + ", firstName=" + firstName + ", lastName=" + lastName + ", username="
				+ username + ", password=" + password + ", email=" + email + ", date=" + date + ", contactNumber="
				+ contactNumber + ", linkedinUrl=" + linkedinUrl + ", yearOfExperiance=" + yearOfExperiance
				+ ", confirmSignUp=" + confirmSignUp + ", resetPassword=" + resetPassword + ", isblock=" + isblock
				+ "]";
	}
	
}
