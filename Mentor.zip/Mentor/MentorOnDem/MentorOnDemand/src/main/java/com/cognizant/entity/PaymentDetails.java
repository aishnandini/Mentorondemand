package com.cognizant.entity;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class PaymentDetails implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7237034953087778362L;
	@Id
	private long id;
	private String txnType;
	private float Amount;	
	private String remark;
	private long mentorId;
	private long mentorName;
	private long skillName;
	private float TotalAmountToMentor;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public float getAmount() {
		return Amount;
	}
	public void setAmount(float amount) {
		Amount = amount;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public long getMentorId() {
		return mentorId;
	}
	public void setMentorId(long mentorId) {
		this.mentorId = mentorId;
	}
	public long getMentorName() {
		return mentorName;
	}
	public void setMentorName(long mentorName) {
		this.mentorName = mentorName;
	}
	public long getSkillName() {
		return skillName;
	}
	public void setSkillName(long skillName) {
		this.skillName = skillName;
	}
	public float getTotalAmountToMentor() {
		return TotalAmountToMentor;
	}
	public void setTotalAmountToMentor(float totalAmountToMentor) {
		TotalAmountToMentor = totalAmountToMentor;
	}
	@Override
	public String toString() {
		return "PaymentDetails [id=" + id + ", txnType=" + txnType + ", Amount=" + Amount + ", remark=" + remark
				+ ", mentorId=" + mentorId + ", mentorName=" + mentorName + ", skillName=" + skillName
				+ ", TotalAmountToMentor=" + TotalAmountToMentor + "]";
	}
	
}
