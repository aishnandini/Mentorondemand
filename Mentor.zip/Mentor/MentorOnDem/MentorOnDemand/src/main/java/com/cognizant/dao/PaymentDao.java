package com.cognizant.dao;


import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.entity.PaymentDetails;


@Repository
public interface PaymentDao extends CrudRepository<PaymentDetails, Serializable>
{
	
	 Iterable<PaymentDetails> findAll();

}
